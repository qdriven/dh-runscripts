+++
icon = "<b>1. </b>"
date = "2016-12-02T16:06:17+08:00"
title = "起航"
weight = 0
prev = "/00-overview/source-code-guide/"
next = "/01-start/quick-start/"
chapter = true
+++

# 本章导航

 - 如果想快速体验Elastic-Job的强大功能，请阅读[快速入门](/01-start/quick-start)。
 - 如果在使用中遇到什么问题，请首先在[FAQ](/01-start/faq)中寻找解决问题的答案。
 - 想要在自己的项目中集成Elastic-Job,您一定很关心它[如何开发](/01-start/dev-guide)及[如何部署](/01-start/deploy-guide)。
