+++
icon = "<b>3. </b>"
date = "2016-12-12T16:06:17+08:00"
title = "设计规划"
weight = 0
prev = "/02-guide/event-trace/"
next = "/03-design/module/"
chapter = true
+++

# 本章导航

 - 想了解模块设计，请阅读[目录结构说明](/03-design/module/)。
 
 - Elastic-Job-Cloud未来规划有哪些呢？请阅读[未来规划](/03-design/roadmap/)。