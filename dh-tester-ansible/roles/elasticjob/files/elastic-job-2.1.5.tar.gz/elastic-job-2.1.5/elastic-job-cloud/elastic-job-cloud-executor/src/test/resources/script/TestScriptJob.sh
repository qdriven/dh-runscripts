#!/bin/bash
echo sharding context is $*
