$(function() {
    validate();
    submitConfirm("put", $("#data-update-app"));
});
